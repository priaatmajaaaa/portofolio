# placement_management_portal
A portal which help aspirants to share their interview experiences and get updates of company requirements and elgibilty criteria 
